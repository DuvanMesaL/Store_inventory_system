<?php $__env->startSection('title', 'Dashboard - Sistema de Inventario'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <!-- Header con saludo personalizado -->
    <div class="mb-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
                <h1 class="text-4xl font-bold text-gray-800 mb-2">
                    ¡Hola, <?php echo e(auth()->user()->name); ?>! 👋
                </h1>
                <p class="text-gray-600 text-lg">Aquí tienes un resumen de tu inventario</p>
            </div>
            <div class="mt-4 md:mt-0 text-right">
                <div class="text-sm text-gray-500"><?php echo e(now()->format('l, d \d\e F \d\e Y')); ?></div>
                <div class="text-lg font-semibold text-gray-700"><?php echo e(now()->format('H:i')); ?></div>
            </div>
        </div>
    </div>

    <!-- Tarjetas de estadísticas mejoradas -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-blue-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600 mb-1">Total Productos</p>
                    <p class="text-3xl font-bold text-gray-900"><?php echo e($totalProducts); ?></p>
                    <p class="text-xs text-green-600 mt-1">
                        <i class="fas fa-arrow-up mr-1"></i>+12% este mes
                    </p>
                </div>
                <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-boxes text-blue-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-green-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600 mb-1">Categorías</p>
                    <p class="text-3xl font-bold text-gray-900"><?php echo e($totalCategories); ?></p>
                    <p class="text-xs text-blue-600 mt-1">
                        <i class="fas fa-info-circle mr-1"></i>Activas
                    </p>
                </div>
                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-tags text-green-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-yellow-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600 mb-1">Proveedores</p>
                    <p class="text-3xl font-bold text-gray-900"><?php echo e($totalSuppliers); ?></p>
                    <p class="text-xs text-purple-600 mt-1">
                        <i class="fas fa-handshake mr-1"></i>Colaboradores
                    </p>
                </div>
                <div class="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-truck text-yellow-600 text-xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-white rounded-xl shadow-lg p-6 card-hover border-l-4 border-red-500">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-medium text-gray-600 mb-1">Stock Bajo</p>
                    <p class="text-3xl font-bold text-gray-900"><?php echo e($lowStockProducts); ?></p>
                    <p class="text-xs text-red-600 mt-1">
                        <i class="fas fa-exclamation-triangle mr-1"></i>Requiere atención
                    </p>
                </div>
                <div class="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle text-red-600 text-xl"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Valores del inventario con diseño mejorado -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div class="bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold mb-2 opacity-90">
                        <i class="fas fa-dollar-sign mr-2"></i>Valor del Inventario
                    </h3>
                    <p class="text-3xl font-bold mb-1">$<?php echo e(number_format($totalInventoryValue, 2)); ?></p>
                    <p class="text-sm opacity-80">Valor total de compra del stock actual</p>
                </div>
                <div class="w-16 h-16 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                    <i class="fas fa-warehouse text-2xl"></i>
                </div>
            </div>
        </div>

        <div class="bg-gradient-to-r from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white card-hover">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold mb-2 opacity-90">
                        <i class="fas fa-chart-line mr-2"></i>Valor Potencial
                    </h3>
                    <p class="text-3xl font-bold mb-1">$<?php echo e(number_format($totalSalesValue, 2)); ?></p>
                    <p class="text-sm opacity-80">Valor si se vende todo el stock</p>
                </div>
                <div class="w-16 h-16 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                    <i class="fas fa-trending-up text-2xl"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Productos con stock bajo mejorado -->
        <div class="bg-white rounded-xl shadow-lg p-6 card-hover">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-exclamation-triangle text-red-500 mr-2"></i>Productos con Stock Bajo
                </h2>
                <?php if($lowStockProducts > 0): ?>
                    <span class="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                        <?php echo e($lowStockProducts); ?> alertas
                    </span>
                <?php endif; ?>
            </div>

            <?php if($lowStockItems->count() > 0): ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $lowStockItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-100 hover:bg-red-100 transition-colors">
                            <div class="flex items-center">
                                <div class="w-10 h-10 bg-red-200 rounded-lg flex items-center justify-center mr-3">
                                    <i class="fas fa-box text-red-600"></i>
                                </div>
                                <div>
                                    <p class="font-semibold text-gray-900"><?php echo e($item->name); ?></p>
                                    <p class="text-sm text-gray-600">
                                        <i class="fas fa-tag mr-1"></i><?php echo e($item->category->name); ?>

                                    </p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-lg font-bold text-red-600"><?php echo e($item->stock_quantity); ?></p>
                                <p class="text-xs text-gray-500">Mín: <?php echo e($item->min_stock_level); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="mt-6">
                    <a href="<?php echo e(route('products.index', ['low_stock' => 1])); ?>"
                       class="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                        Ver todos los productos con stock bajo
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">¡Excelente!</h3>
                    <p class="text-gray-600">No hay productos con stock bajo.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Movimientos recientes mejorado -->
        <div class="bg-white rounded-xl shadow-lg p-6 card-hover">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-800">
                    <i class="fas fa-history mr-2"></i>Movimientos Recientes
                </h2>
                <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                    Últimos 10
                </span>
            </div>

            <?php if($recentMovements->count() > 0): ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $recentMovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                            <div class="flex items-center">
                                <div class="w-10 h-10 rounded-lg flex items-center justify-center mr-3
                                    <?php if($movement->type == 'in'): ?> bg-green-100 <?php elseif($movement->type == 'out'): ?> bg-red-100 <?php else: ?> bg-blue-100 <?php endif; ?>">
                                    <?php if($movement->type == 'in'): ?>
                                        <i class="fas fa-arrow-up text-green-600"></i>
                                    <?php elseif($movement->type == 'out'): ?>
                                        <i class="fas fa-arrow-down text-red-600"></i>
                                    <?php else: ?>
                                        <i class="fas fa-edit text-blue-600"></i>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <p class="font-semibold text-gray-900"><?php echo e($movement->product->name); ?></p>
                                    <p class="text-sm text-gray-600">
                                        <span class="
                                            <?php if($movement->type == 'in'): ?> text-green-600
                                            <?php elseif($movement->type == 'out'): ?> text-red-600
                                            <?php else: ?> text-blue-600 <?php endif; ?>">
                                            <?php echo e($movement->type_text); ?>

                                        </span>
                                        - <?php echo e($movement->quantity); ?> unidades
                                    </p>
                                </div>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-900">
                                    <?php echo e($movement->created_at->format('H:i')); ?>

                                </p>
                                <p class="text-xs text-gray-500">
                                    <?php echo e($movement->created_at->format('d/m/Y')); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="text-center py-12">
                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-inbox text-gray-400 text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Sin movimientos</h3>
                    <p class="text-gray-600">No hay movimientos recientes registrados.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Estadísticas por categoría mejoradas -->
    <?php if($categoryStats->count() > 0): ?>
    <div class="bg-white rounded-xl shadow-lg p-6 mt-8 card-hover">
        <div class="flex items-center justify-between mb-6">
            <h2 class="text-xl font-bold text-gray-800">
                <i class="fas fa-chart-pie mr-2"></i>Distribución por Categorías
            </h2>
            <span class="bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
                <?php echo e($categoryStats->count()); ?> categorías
            </span>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <?php $__currentLoopData = $categoryStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-gradient-to-r from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-100 hover:shadow-md transition-all">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="font-semibold text-gray-900"><?php echo e($category->name); ?></p>
                            <p class="text-sm text-gray-600"><?php echo e($category->products_count); ?> productos</p>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                            <span class="text-lg font-bold text-purple-600"><?php echo e($category->products_count); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Acciones rápidas -->
    <div class="bg-white rounded-xl shadow-lg p-6 mt-8 card-hover">
        <h2 class="text-xl font-bold text-gray-800 mb-6">
            <i class="fas fa-bolt mr-2"></i>Acciones Rápidas
        </h2>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <a href="<?php echo e(route('products.create')); ?>" class="flex items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors group">
                <div class="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <i class="fas fa-plus text-white"></i>
                </div>
                <div>
                    <p class="font-semibold text-gray-900">Nuevo Producto</p>
                    <p class="text-xs text-gray-600">Agregar al inventario</p>
                </div>
            </a>

            <?php if(auth()->user()->canManageProducts()): ?>
            <a href="<?php echo e(route('categories.create')); ?>" class="flex items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors group">
                <div class="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <i class="fas fa-tag text-white"></i>
                </div>
                <div>
                    <p class="font-semibold text-gray-900">Nueva Categoría</p>
                    <p class="text-xs text-gray-600">Organizar productos</p>
                </div>
            </a>

            <a href="<?php echo e(route('suppliers.create')); ?>" class="flex items-center p-4 bg-yellow-50 rounded-lg hover:bg-yellow-100 transition-colors group">
                <div class="w-10 h-10 bg-yellow-500 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <i class="fas fa-truck text-white"></i>
                </div>
                <div>
                    <p class="font-semibold text-gray-900">Nuevo Proveedor</p>
                    <p class="text-xs text-gray-600">Gestionar proveedores</p>
                </div>
            </a>
            <?php endif; ?>

            <a href="<?php echo e(route('products.index', ['low_stock' => 1])); ?>" class="flex items-center p-4 bg-red-50 rounded-lg hover:bg-red-100 transition-colors group">
                <div class="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <i class="fas fa-exclamation-triangle text-white"></i>
                </div>
                <div>
                    <p class="font-semibold text-gray-900">Stock Bajo</p>
                    <p class="text-xs text-gray-600">Revisar alertas</p>
                </div>
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\store_inventory_system\resources\views/dashboard.blade.php ENDPATH**/ ?>