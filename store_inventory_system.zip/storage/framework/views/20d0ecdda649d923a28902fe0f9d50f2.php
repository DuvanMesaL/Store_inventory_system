<?php $__env->startSection('icon', '🎉'); ?>
<?php $__env->startSection('title', '¡Bienvenido!'); ?>
<?php $__env->startSection('subtitle', 'Tu cuenta ha sido creada exitosamente'); ?>

<?php $__env->startSection('content'); ?>
    <div class="greeting">
        ¡Hola <?php echo e($user->name); ?>! 👋
    </div>

    <div class="content-text">
        ¡Te damos la más cordial <strong>bienvenida</strong> a nuestro Sistema de Inventario! 🚀
    </div>

    <div class="content-text">
        Tu cuenta ha sido creada exitosamente y ya puedes comenzar a gestionar el inventario de tu tienda de manera eficiente.
    </div>

    <div class="alert alert-info">
        <strong>🎯 Tu rol actual:</strong> <?php echo e(ucfirst($user->role)); ?>

    </div>

    <div class="content-text">
        <strong>🌟 Características principales que puedes usar:</strong>
    </div>

    <div class="product-list">
        <div class="product-item">
            <div>
                <div class="product-name">📦 Gestión completa de productos</div>
                <div class="product-details">Agregar, editar y organizar tu inventario</div>
            </div>
        </div>
        <div class="product-item">
            <div>
                <div class="product-name">📊 Control de stock en tiempo real</div>
                <div class="product-details">Monitoreo automático de existencias</div>
            </div>
        </div>
        <div class="product-item">
            <div>
                <div class="product-name">⚠️ Alertas automáticas de stock bajo</div>
                <div class="product-details">Nunca te quedes sin productos</div>
            </div>
        </div>
        <div class="product-item">
            <div>
                <div class="product-name">📈 Reportes y estadísticas detalladas</div>
                <div class="product-details">Análisis completo de tu inventario</div>
            </div>
        </div>
        <div class="product-item">
            <div>
                <div class="product-name">🏷️ Organización por categorías</div>
                <div class="product-details">Mantén todo ordenado y fácil de encontrar</div>
            </div>
        </div>
        <div class="product-item">
            <div>
                <div class="product-name">🚚 Gestión de proveedores</div>
                <div class="product-details">Control completo de tus socios comerciales</div>
            </div>
        </div>
    </div>

    <div class="button-container">
        <a href="<?php echo e(route('dashboard')); ?>" class="button">
            🚀 Acceder al Sistema
        </a>
    </div>

    <div class="alert alert-success">
        <strong>💡 Consejo:</strong> Comienza creando algunas categorías y luego agrega tus primeros productos.
    </div>

    <div class="content-text">
        📞 Si tienes alguna pregunta o necesitas ayuda, no dudes en contactarnos. ¡Estamos aquí para apoyarte!
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-links'); ?>
    <a href="<?php echo e(route('dashboard')); ?>">Ir al Dashboard</a>
    <a href="mailto:<?php echo e(config('mail.from.address')); ?>">Contacto</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Duvan\Desktop\laragon-6.0.0\www\Proyectos-I.E-Bertha-Suttner\store_inventory_system\resources\views/emails/welcome.blade.php ENDPATH**/ ?>